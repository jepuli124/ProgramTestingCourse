package com.example;

import java.util.ArrayList;

public class DatabaseStub {

    public String getCourseName(String id) {
        return null;
    }

    public ArrayList<Integer> getGrades(String id) {
        return null;
    }

}
