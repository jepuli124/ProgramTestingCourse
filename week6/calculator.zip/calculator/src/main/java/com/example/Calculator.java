package com.example;

import java.util.ArrayList;
import java.util.Scanner;

public class Calculator {
    private Scanner scanner;
    private ArrayList<Integer> vec;

    public Calculator(Scanner scanner) {
        this.scanner = scanner;
    }

    public void askGrades() {
        vec = new ArrayList<>();
        int i = 1;
        String s = "";

        System.out.println(
                "***\nThis program calculates average of school grades (4-10). Input number, press enter. Zero (0) ends the input.");

        while (!s.contains("0")) {
            System.out.println(i + ": ");
            if (scanner.hasNext()) {
                s = scanner.nextLine();
                vec.add(Integer.parseInt(s));
                i++;
            }
        }

    }

    public float calculateAverage() {
        return divider(sum(vec), vec.size());
    }

    public float divider(int x, int y) {
        System.out.println(x + " " + y);
        return x / (float) y;
    }

    public int sum(ArrayList<Integer> vec) {
        int s = 0;

        for (int i : vec) {
            s += i;
        }

        return s;
    }

    public ArrayList<Integer> getVec() {
        return vec;
    }

}
